# 🧩 SupplyApply Dashboard
Created by **Tom Truong**

> Realtime Inventory & Report Dashboard powered by Google Sheets (Apps Script)  
> Auto-deploy with Netlify – built for **Supply & Apply** internal use.

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start)

---

## 🚀 Quick Start

### 1️⃣ Setup Backend (Google Apps Script)
1. Open [Google Apps Script](https://script.google.com/).
2. Create a new project and paste:
   ```js
   function doGet(e) {
     const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Inventory");
     const data = sheet.getDataRange().getDisplayValues();
     return ContentService
       .createTextOutput(JSON.stringify(data))
       .setMimeType(ContentService.MimeType.JSON);
   }